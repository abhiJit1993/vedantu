const mongo = require('mongodb');
var MongoClient = require('mongodb').MongoClient;
const url = "mongodb://localhost:27017/";
var ObjectId = require('mongodb').ObjectId


module.exports = {

    getAllInventories: function (req, res, next) {
        console.log(req.body);

        MongoClient.connect(url, function (err, db) {
            if (err) throw err;
            var dbo = db.db("shoppersKart");
            dbo.collection("inventories").find({}).toArray(function (err, result) {
                if (err) throw err;
                console.log(result);
                db.close();
                res.status(200).json({ "Items": result });



            });
        });

    },
    placeOrder: function (req, res, next) {
        var items = req.body.items.split(",");
        var queryStringArr  = '';
        var itemsArr = req.body.items.split(",");
        const loggedInUserId = "5c80bcdd62ce526dbac8c45a";

        MongoClient.connect(url, function (err, db) {
            if (err) throw err;
            var dbo = db.db("shoppersKart");
             itemsArr.forEach(id => {
                 if(!(itemsArr.indexOf(id) == itemsArr.length-1 ))
                queryStringArr.concat(`{ObjectId("`+id+`")},`)
                else{
                    queryStringArr.concat(`{ObjectId("`+id+`")}`)
                }
             })

            var query = `{$or: [`+queryStringArr+`]}`;
            var unavailableItems = [];
            var orders = [];

            dbo.collection("inventories").find(query).toArray(function (err, result) {
                if (err) throw err;
                else {
                    result.forEach(element => {
                        if (element.available_stocks === 0) {
                            unavailableItems.push(element);
                        } else {
                            orders.push({
                                "item_id": element._id,
                                "status": "placed",
                                userId: loggedInUserId,
                                orderDateAndTime: new Date()
                            })
                        }
                    });
                    
                    dbo.collection("order_history").insertMany(orders, function (err, resp) {
                        if (err) throw err;
                        console.log(orders.length + " orders placed");
                        res.status(200).json({ "AvailableItems": result, unavailableItems: unavailableItems });

                        db.close();
                    });
                }
            })
        });
    }
}
