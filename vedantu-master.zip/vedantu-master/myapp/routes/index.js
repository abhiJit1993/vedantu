var express = require('express');
var router = express.Router();
const inventoryController = require('../controllers/inventoryController')
router.get('/getAvailableItems', inventoryController.getAllInventories);
router.post('/placeOrder', inventoryController.placeOrder);

module.exports = router;
